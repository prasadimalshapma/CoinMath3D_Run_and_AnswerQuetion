using UnityEngine;

public class Level3Mission1Trigger : MonoBehaviour
{
    [SerializeField] private Level3Mission1Manager mcqManager;
    [SerializeField] private Animator playerAnimator;

    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || hasBeenAsked) return;

        if (playerAnimator == null)
            playerAnimator = other.GetComponent<Animator>();

        hasBeenAsked = true;

        string question = "Out of 2500 employees, only 30% came to work today. How many came?.:";
        string[] options = { "770", "750", "700", "800" };
        int correctAnswerIndex = 1;

        mcqManager.ShowQuestion(question, options, correctAnswerIndex, playerAnimator);
    }
}
