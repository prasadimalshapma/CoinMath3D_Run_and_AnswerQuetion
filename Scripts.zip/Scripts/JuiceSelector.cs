﻿using UnityEngine;

public class JuiceSelector : MonoBehaviour
{
    public GameObject hungryPanel;
    public Animator playerAnimator; 

    private int[] juicePrices = { 25, 100, 50, 45 };
    private string[] juiceNames = { "Apple Juice", "Orange Juice", "Mango Juice", "Pineapple Juice" };

    void Update()
    {
        if (hungryPanel.activeSelf)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1))
                TryBuyJuice(0);
            else if (Input.GetKeyDown(KeyCode.Alpha2))
                TryBuyJuice(1);
            else if (Input.GetKeyDown(KeyCode.Alpha3))
                TryBuyJuice(2);
            else if (Input.GetKeyDown(KeyCode.Alpha4))
                TryBuyJuice(3);
        }
    }

    void TryBuyJuice(int index)
    {
        int price = juicePrices[index];
        string name = juiceNames[index];

        if (CoinManager.Instance.SpendCoins(price))
        {
            Debug.Log("Bought " + name + " for " + price + " coins.");
            hungryPanel.SetActive(false);

            if (playerAnimator != null)
                StartCoroutine(PlayDrinkAnimation());
        }
        else
        {
            Debug.Log("Not enough coins to buy " + name);
        }
    }

    System.Collections.IEnumerator PlayDrinkAnimation()
    {
        playerAnimator.SetTrigger("drink");
        yield return new WaitForSeconds(3f);
        
    }
}
