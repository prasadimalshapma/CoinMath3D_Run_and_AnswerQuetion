﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;

public class PondMCQManager : MonoBehaviour
{
    public TextMeshProUGUI questionText;
    public Button[] optionButtons;
    public int correctAnswerIndex;

    public GameObject mcqPanel;
    public TextMeshProUGUI feedbackText;

    public Color correctColor = Color.green;
    public Color wrongColor = Color.red;

    private bool answered = false;

    public PondQuizTrigger quizTrigger;

    public void SetQuestion(string question, string[] options, int correctIndex)
    {
        questionText.text = question;
        correctAnswerIndex = correctIndex;
        answered = false;

        for (int i = 0; i < optionButtons.Length; i++)
        {
            int index = i;
            optionButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = options[i];
            optionButtons[i].onClick.RemoveAllListeners();
            optionButtons[i].onClick.AddListener(() => CheckAnswer(index));
            optionButtons[i].GetComponent<Image>().color = Color.white;
            optionButtons[i].interactable = true;
        }

        if (mcqPanel != null)
            mcqPanel.SetActive(true);

        if (feedbackText != null)
            feedbackText.gameObject.SetActive(false);
    }

    void Update()
    {
        if (answered) return;

        if (Input.GetKeyDown(KeyCode.Alpha1)) SelectAnswer(0);
        if (Input.GetKeyDown(KeyCode.Alpha2)) SelectAnswer(1);
        if (Input.GetKeyDown(KeyCode.Alpha3)) SelectAnswer(2);
        if (Input.GetKeyDown(KeyCode.Alpha4)) SelectAnswer(3);
    }

    private void SelectAnswer(int index)
    {
        if (index >= 0 && index < optionButtons.Length)
        {
            CheckAnswer(index);
        }
    }

    public void CheckAnswer(int selectedIndex)
    {
        if (answered) return;
        answered = true;

        if (selectedIndex == correctAnswerIndex)
        {
            optionButtons[selectedIndex].GetComponent<Image>().color = correctColor;
            ShowFeedback("✅ Correct Answer!", Color.green);
            Debug.Log("Correct Answer!");
            CoinManager.Instance.AddCoin(10);
        }
        else
        {
            optionButtons[selectedIndex].GetComponent<Image>().color = wrongColor;
            optionButtons[correctAnswerIndex].GetComponent<Image>().color = correctColor;
            ShowFeedback("❌ Wrong Answer!", Color.red);
            Debug.Log("Wrong Answer!");
        }

        foreach (Button btn in optionButtons)
            btn.interactable = false;

        if (quizTrigger != null)
            quizTrigger.EndQuiz();

        StartCoroutine(HidePanelAfterDelay(2f));
    }

    private void ShowFeedback(string message, Color color)
    {
        if (feedbackText != null)
        {
            feedbackText.text = message;
            feedbackText.color = color;
            feedbackText.gameObject.SetActive(true);
            StartCoroutine(HideFeedbackAfterDelay(2f));
        }
    }

    private IEnumerator HideFeedbackAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (feedbackText != null)
            feedbackText.gameObject.SetActive(false);
    }

    private IEnumerator HidePanelAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (mcqPanel != null)
            mcqPanel.SetActive(false);
    }
}
