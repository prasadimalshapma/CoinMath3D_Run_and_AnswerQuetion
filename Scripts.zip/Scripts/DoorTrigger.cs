using UnityEngine;

public class DoorTrigger : MonoBehaviour
{
    public Transform door;        
    public float openAngle = -90f;  
    public float speed = 2f;      
    public string playerTag = "Player";

    private bool open = false;
    private Quaternion initialRotation;
    private Quaternion targetRotation;

    void Start()
    {
        initialRotation = door.rotation;
        targetRotation = door.rotation * Quaternion.Euler(openAngle, 0, 0); 
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(playerTag)) 
        {
            open = true;
        }
    }

    void Update()
    {
        if (open)
        {
            door.rotation = Quaternion.Lerp(door.rotation, targetRotation, Time.deltaTime * speed);
        }
    }
}
