using UnityEngine;
using System.Collections;

public class BusMovement : MonoBehaviour
{
    public Transform[] waypoints;
    public float speed = 8f;
    public Transform[] wheels;
    public float wheelRotationSpeed = 360f;

    private int currentIndex = 0;
    private bool isPaused = false;

    void Start()
    {
        if (waypoints.Length > 1)
        {
            transform.LookAt(waypoints[1].position);
        }
    }

    void Update()
    {
        if (waypoints.Length == 0 || isPaused) return;

        Transform target = waypoints[currentIndex];
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

        foreach (Transform wheel in wheels)
        {
            wheel.Rotate(Vector3.right, wheelRotationSpeed * Time.deltaTime);
        }

        if (Vector3.Distance(transform.position, target.position) < 0.1f)
        {
            currentIndex++;

            if (currentIndex < waypoints.Length)
            {
                transform.LookAt(waypoints[currentIndex].position);
            }
            else
            {
                currentIndex = 0;
                transform.LookAt(waypoints[currentIndex].position);
            }
        }
    }

   
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("BusStop"))
        {
            StartCoroutine(PauseAtBusStop());
        }
    }

    IEnumerator PauseAtBusStop()
    {
        isPaused = true;
        yield return new WaitForSeconds(3f); 
        isPaused = false;
    }
}
