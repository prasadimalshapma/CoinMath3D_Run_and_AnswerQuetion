using UnityEngine;

public class AudioTest : MonoBehaviour
{
    void Start()
    {
        GetComponent<AudioSource>().Play();
    }
}
