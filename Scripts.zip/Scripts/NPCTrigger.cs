using UnityEngine;
using UnityEngine.UI; 

public class NPCTrigger : MonoBehaviour
{
    public GameObject messagePanel; 
    public string message = "Hi";

    void Start()
    {
        if (messagePanel != null)
            messagePanel.SetActive(false);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (messagePanel != null)
            {
                messagePanel.SetActive(true);
                messagePanel.GetComponentInChildren<Text>().text = message;
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (messagePanel != null)
            {
                messagePanel.SetActive(false);
            }
        }
    }
}