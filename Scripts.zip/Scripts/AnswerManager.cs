﻿using UnityEngine;
using TMPro;

public class AnswerManager : MonoBehaviour
{
    public int correctAnswerIndex = 2; 
    public TextMeshProUGUI feedbackText;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            CheckAnswer(1);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            CheckAnswer(2);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            CheckAnswer(3);
        }
        else if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            CheckAnswer(4);
        }
    }

    void CheckAnswer(int selectedAnswer)
    {
        if (selectedAnswer == correctAnswerIndex)
        {
            feedbackText.text = "✅ Correct Answer!";
            feedbackText.color = Color.green;
        }
        else
        {
            feedbackText.text = "❌ Wrong Answer!";
            feedbackText.color = Color.red;
        }
    }
}
