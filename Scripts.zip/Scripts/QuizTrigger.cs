﻿using UnityEngine;
using TMPro;
using System.Collections;

public class QuizTrigger : MonoBehaviour
{
    [SerializeField] private GameObject mcqPanel;
    [SerializeField] private MCQManager mcqManager;
    [SerializeField] private string question;
    [SerializeField] private string[] options;
    [SerializeField] private int correctAnswerIndex;

    [SerializeField] private Animator npcAnimator;
    [SerializeField] private string npcBoolName = "IsTalking";

    [SerializeField] private TextMeshProUGUI messageText;

    private Animator playerAnimator;
    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        if (npcAnimator != null)
            npcAnimator.SetBool(npcBoolName, true);

        if (playerAnimator == null)
            playerAnimator = other.GetComponent<Animator>();

        if (playerAnimator != null)
            playerAnimator.SetBool("IsTalking", true);

        if (!hasBeenAsked)
        {
            if (mcqPanel != null && mcqManager != null)
            {
                mcqPanel.SetActive(true);
                mcqManager.SetQuestion(question, options, correctAnswerIndex, this);
                hasBeenAsked = true;
            }

            if (messageText != null)
                messageText.gameObject.SetActive(false);
        }
        else
        {
            if (messageText != null)
            {
                messageText.text = "Sorry, you already answered this!";
                messageText.gameObject.SetActive(true);
                StopAllCoroutines();
                StartCoroutine(HideMessageAfterDelay(2f));
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        if (npcAnimator != null)
            npcAnimator.SetBool(npcBoolName, false);

        if (playerAnimator != null)
            playerAnimator.SetBool("IsTalking", false);

        if (mcqPanel != null)
            mcqPanel.SetActive(false);

        if (messageText != null)
            messageText.gameObject.SetActive(false);
    }

    private IEnumerator HideMessageAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (messageText != null)
            messageText.gameObject.SetActive(false);
    }

    public void EndQuiz()
    {
        if (npcAnimator != null)
            npcAnimator.SetBool(npcBoolName, false);

        if (playerAnimator != null)
            playerAnimator.SetBool("IsTalking", false);
    }
}
