﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;

public class Level3Mission1Manager : MonoBehaviour
{
    public GameObject watermarkpanal;
    public TextMeshProUGUI questionText;
    public Button[] optionButtons;
    public TextMeshProUGUI feedbackText;
    public Color correctColor = Color.green;
    public Color wrongColor = Color.red;

    private int correctAnswerIndex;
    private bool answered = false;
    private Animator playerAnimator;
    private bool isListening = false;

    void Update()
    {
        if (!isListening || answered) return;

        if (Input.GetKeyDown(KeyCode.Alpha1)) CheckAnswer(0);
        if (Input.GetKeyDown(KeyCode.Alpha2)) CheckAnswer(1);
        if (Input.GetKeyDown(KeyCode.Alpha3)) CheckAnswer(2);
        if (Input.GetKeyDown(KeyCode.Alpha4)) CheckAnswer(3);
    }

    public void ShowQuestion(string question, string[] options, int correctIndex, Animator playerAnim)
    {
        watermarkpanal.SetActive(true);
        answered = false;
        isListening = true;
        correctAnswerIndex = correctIndex;
        playerAnimator = playerAnim;

        questionText.text = question;
        feedbackText.gameObject.SetActive(false);

        for (int i = 0; i < optionButtons.Length; i++)
        {
            int index = i;
            optionButtons[i].interactable = true;
            optionButtons[i].GetComponent<Image>().color = Color.white;
            optionButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = options[i];
            optionButtons[i].onClick.RemoveAllListeners();
            optionButtons[i].onClick.AddListener(() => CheckAnswer(index));
        }
    }

    public void CheckAnswer(int selectedIndex)
    {
        if (answered) return;
        answered = true;
        isListening = false;

        foreach (Button btn in optionButtons)
            btn.interactable = false;

        if (selectedIndex == correctAnswerIndex)
        {
            optionButtons[selectedIndex].GetComponent<Image>().color = correctColor;
            feedbackText.text = "🎉 Congratulations!";
            feedbackText.color = correctColor;
            CoinManager.Instance.AddCoin(100);
        }
        else
        {
            optionButtons[selectedIndex].GetComponent<Image>().color = wrongColor;
            optionButtons[correctAnswerIndex].GetComponent<Image>().color = correctColor;
            feedbackText.text = "❌ Mission Failed!";
            feedbackText.color = wrongColor;

            if (playerAnimator != null)
                playerAnimator.SetTrigger("sad");
        }

        feedbackText.gameObject.SetActive(true);
        StartCoroutine(HidePanelAfterDelay(3f));
    }

    private IEnumerator HidePanelAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        watermarkpanal.SetActive(false);
    }
}
