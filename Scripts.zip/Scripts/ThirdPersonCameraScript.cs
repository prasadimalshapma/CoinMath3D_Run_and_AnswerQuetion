﻿using UnityEngine;

public class ThirdPersonCamera : MonoBehaviour
{
    public Transform target;
    public float distance = 5.0f;
    public float height = 2.0f;
    public float rotationSpeed = 100.0f;

    private float currentX = 0f;
    private float currentY = 10f;

    void Update()
    {
        if (target == null) return;

        currentX += Input.GetAxis("Mouse X") * rotationSpeed * Time.deltaTime;
        currentY -= Input.GetAxis("Mouse Y") * rotationSpeed * Time.deltaTime;
        currentY = Mathf.Clamp(currentY, -20f, 60f);
    }

    void LateUpdate()
    {
        if (target == null) return;

        Quaternion rotation = Quaternion.Euler(currentY, currentX, 0);
        Vector3 position = target.position - (rotation * Vector3.forward * distance) + (Vector3.up * height);

        transform.position = position;
        transform.LookAt(target);
    }

    
    public void ResetCamera()
    {
        currentX = 0f;
        currentY = 10f;
    }
}
