using UnityEngine;

public class CoinCheckTrigger : MonoBehaviour
{
    public GameObject gameWinPanel;
    public GameObject gameLostPanel;

    private Animator playerAnimator;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            playerAnimator = other.GetComponent<Animator>();

            int totalCoins = CoinManager.Instance.coins;

            if (totalCoins >= 1200)
            {
                gameWinPanel.SetActive(true);
                gameLostPanel.SetActive(false);

                if (playerAnimator != null)
                {
                    
                    playerAnimator.SetTrigger("Victory");
                }
            }
            else
            {
                gameWinPanel.SetActive(false);
                gameLostPanel.SetActive(true);

                if (playerAnimator != null)
                {
                   
                    playerAnimator.SetTrigger("sad");
                }
            }
        }
    }
}
