using UnityEngine;

public class EnemyHintTrigger : MonoBehaviour
{
    public GameObject hintUI;
    private bool playerInRange = false;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            hintUI.SetActive(true);
            playerInRange = true;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            hintUI.SetActive(false);
            playerInRange = false;
        }
    }

    void Update()
    {
        if (playerInRange && Input.GetKeyDown(KeyCode.Return))
        {
            Debug.Log("Player attacks enemy!");
            hintUI.SetActive(false);
            
        }
    }
}
