using UnityEngine;

public class Level3ResetTrigger : MonoBehaviour
{
    public GameManager gameManager;
    public Transform targetPosition; 
    private bool isPlayerInside = false;
    private GameObject player;

    void Update()
    {
        if (isPlayerInside && Input.GetKeyDown(KeyCode.R))
        {
            MovePlayerToTarget();
            gameManager.RestartLevel();
        }
    }

    void MovePlayerToTarget()
    {
        if (player != null && targetPosition != null)
        {
            player.transform.position = targetPosition.position;
            Debug.Log("Player moved to reset position.");
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInside = true;
            player = other.gameObject;
            Debug.Log("Player entered reset zone. Press R to restart level.");
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInside = false;
            player = null;
        }
    }
}
