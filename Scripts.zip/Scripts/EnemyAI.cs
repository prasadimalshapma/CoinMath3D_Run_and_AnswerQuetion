﻿using UnityEngine;
using UnityEngine.AI;

public class EnemyAI : MonoBehaviour
{
    public Transform player;
    public float chaseRange = 10f;      
    public float attackRange = 5f;      
    public float attackCooldown = 1.5f; 

    private NavMeshAgent agent;
    private Animator animator;
    private float lastAttackTime;
    private bool isAttacking = false;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        float distance = Vector3.Distance(transform.position, player.position);

        if (distance <= chaseRange)
        {
            
            Vector3 direction = (player.position - transform.position).normalized;
            Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f);

            if (distance > attackRange)
            {
                
                agent.isStopped = false;
                agent.SetDestination(player.position);
                animator.SetBool("isRunning", true);
            }
            else
            {
                
                agent.ResetPath();
                agent.isStopped = true;
                animator.SetBool("isRunning", false);

                if (!isAttacking && Time.time > lastAttackTime + attackCooldown)
                {
                    StartCoroutine(AttackPlayer());
                    lastAttackTime = Time.time;
                }
            }
        }
        else
        {
            
            agent.ResetPath();
            agent.isStopped = true;
            animator.SetBool("isRunning", false);
        }
    }

    System.Collections.IEnumerator AttackPlayer()
    {
        isAttacking = true;
        agent.isStopped = true;
        animator.SetBool("isRunning", false);
        animator.SetTrigger("isAttacking");

        Debug.Log("Enemy attacks player!");

        yield return new WaitForSeconds(1.0f); 

        isAttacking = false;
        agent.isStopped = false;
    }

    public void Die()
    {
        agent.isStopped = true;
        animator.SetTrigger("Die");
        Debug.Log("Enemy died");
    }
}
