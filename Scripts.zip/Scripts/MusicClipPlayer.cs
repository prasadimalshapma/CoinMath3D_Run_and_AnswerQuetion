using UnityEngine;

public class MusicClipPlayer : MonoBehaviour
{
    public AudioSource audioSource;
    public float startTime = 10f;  
    public float endTime = 100f;    

    void Start()
    {
        audioSource.time = startTime;
        audioSource.Play();
    }

    void Update()
    {
        if (audioSource.isPlaying && audioSource.time >= endTime)
        {
            audioSource.Stop();
        }
    }
}
