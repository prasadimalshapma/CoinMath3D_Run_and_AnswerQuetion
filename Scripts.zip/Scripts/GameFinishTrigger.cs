using UnityEngine;

public class GameFinishTrigger : MonoBehaviour
{
    public GameObject gameWinPanel;
    public GameObject gameLostPanel;
    public int requiredCoins = 1200;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            int totalCoins = CoinManager.Instance.coins;

            if (totalCoins >= requiredCoins)
            {
                gameWinPanel.SetActive(true);
                Debug.Log("You Win!");
            }
            else
            {
                gameLostPanel.SetActive(true);
                Debug.Log("You Lose!");
            }
        }
    }
}
