﻿using UnityEngine;

public class VehicleEnterTrigger : MonoBehaviour
{
    public Transform seatPoint;

    private GameObject player;
    private SkinnedMeshRenderer playerMesh;
    private VehicleController controller;

    private bool isPlayerDriving = false;

    private Vector3 exitOffset = new Vector3(2f, 0, 0); 

    void Start()
    {
        controller = GetComponentInParent<VehicleController>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !isPlayerDriving)
        {
            EnterVehicle(other.gameObject);
        }
    }

    void Update()
    {
        if (isPlayerDriving && Input.GetKeyDown(KeyCode.E))
        {
            ExitVehicle();
        }
    }

    void EnterVehicle(GameObject playerObj)
    {
        player = playerObj;

        
        player.transform.position = seatPoint.position;
        player.transform.rotation = seatPoint.rotation;

       
        player.transform.SetParent(seatPoint);

        
        playerMesh = player.GetComponentInChildren<SkinnedMeshRenderer>();
        if (playerMesh != null)
        {
            playerMesh.enabled = false;
        }

        
        if (controller != null)
        {
            controller.SetDriving(true);
        }

        isPlayerDriving = true;
    }

    void ExitVehicle()
    {
        if (player == null) return;

       
        player.transform.SetParent(null);

        
        player.transform.position = transform.position + exitOffset;

        
        if (playerMesh != null)
        {
            playerMesh.enabled = true;
        }

        
        if (controller != null)
        {
            controller.SetDriving(false);
        }

        
        player = null;
        playerMesh = null;
        isPlayerDriving = false;
    }
}
