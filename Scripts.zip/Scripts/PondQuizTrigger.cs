using UnityEngine;
using TMPro;
using System.Collections;

public class PondQuizTrigger : MonoBehaviour
{
    [SerializeField] private GameObject mcqPanel;
    [SerializeField] private PondMCQManager mcqManager;
    [SerializeField] private string question;
    [SerializeField] private string[] options;
    [SerializeField] private int correctAnswerIndex;

    [SerializeField] private TextMeshProUGUI messageText;

    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        if (!hasBeenAsked)
        {
            if (mcqPanel != null)
            {
                mcqPanel.SetActive(true);
                mcqManager.SetQuestion(question, options, correctAnswerIndex);
                mcqManager.quizTrigger = this;
                hasBeenAsked = true;
            }

            if (messageText != null)
                messageText.gameObject.SetActive(false);
        }
        else
        {
            if (messageText != null)
            {
                messageText.text = "Sorry, you already answered this!";
                messageText.gameObject.SetActive(true);
                StopAllCoroutines();
                StartCoroutine(HideMessageAfterDelay(2f));
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (!other.CompareTag("Player")) return;

        if (mcqPanel != null)
            mcqPanel.SetActive(false);

        if (messageText != null)
            messageText.gameObject.SetActive(false);
    }

    private IEnumerator HideMessageAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        if (messageText != null)
            messageText.gameObject.SetActive(false);
    }

    public void EndQuiz()
    {
        
    }
}
