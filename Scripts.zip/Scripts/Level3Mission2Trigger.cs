using UnityEngine;

public class Level3Mission2Trigger : MonoBehaviour
{
    [SerializeField] private Level3Mission2Manager mcqManager;
    [SerializeField] private Animator playerAnimator;

    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || hasBeenAsked) return;

        if (playerAnimator == null)
            playerAnimator = other.GetComponent<Animator>();

        hasBeenAsked = true;

        string question = "Patient Medical Report";
        string[] options = { "300", "400", "330", "440" };
        int correctAnswerIndex = 1;

        mcqManager.ShowQuestion(question, options, correctAnswerIndex, playerAnimator);
    }
}
