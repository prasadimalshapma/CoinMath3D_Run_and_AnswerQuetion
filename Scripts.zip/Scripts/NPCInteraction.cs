﻿using UnityEngine;
using UnityEngine.UI;

public class NPCInteraction : MonoBehaviour
{
    [SerializeField] private GameObject dialogueUI;
    [SerializeField] private Button optionAButton;
    [SerializeField] private Button optionBButton;
    [SerializeField] private Button optionCButton;

    [SerializeField] private string correctAnswer = "B"; 

    private void Start()
    {
       
        if (dialogueUI == null) Debug.LogError("Dialogue UI is not assigned!");
        if (optionAButton == null) Debug.LogError("Option A Button is not assigned!");
        if (optionBButton == null) Debug.LogError("Option B Button is not assigned!");
        if (optionCButton == null) Debug.LogError("Option C Button is not assigned!");

        dialogueUI.SetActive(false); 
        AddButtonListeners();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            dialogueUI.SetActive(true); 
            Debug.Log("Player entered the trigger zone!");
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            dialogueUI.SetActive(false); 
            Debug.Log("Player exited the trigger zone!");
        }
    }

    private void AddButtonListeners()
    {
        optionAButton.onClick.AddListener(() => CheckAnswer("A"));
        optionBButton.onClick.AddListener(() => CheckAnswer("B"));
        optionCButton.onClick.AddListener(() => CheckAnswer("C"));
    }

    private void CheckAnswer(string selectedOption)
    {
        if (selectedOption == correctAnswer)
        {
            Debug.Log("Correct Answer!");
        }
        else
        {
            Debug.Log("Wrong Answer!");
        }

        dialogueUI.SetActive(false);
    }
}
