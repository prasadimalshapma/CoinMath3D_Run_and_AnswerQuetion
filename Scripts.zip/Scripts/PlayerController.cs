using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float mouseSensitivity = 1f;
    public Transform cameraTransform; 
    public Vector3 cameraOffset = new Vector3(0, 3, -5); 

    private float rotationY = 0f;

    void Update()
    {
        
        float moveX = Input.GetAxis("Horizontal"); 
        float moveZ = Input.GetAxis("Vertical");   

        Vector3 moveDirection = transform.forward * moveZ + transform.right * moveX;
        transform.position += moveDirection * moveSpeed * Time.deltaTime;

       

       
        cameraTransform.position = transform.position + transform.rotation * cameraOffset;
        cameraTransform.LookAt(transform.position + Vector3.up * 1.5f); 
    }
}