using UnityEngine;

public class HideEffectOnTrigger : MonoBehaviour
{
    public GameObject waterEffect; 

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            waterEffect.SetActive(false); 
        }
    }
}
