using UnityEngine;
using TMPro;

public class NPCInteractable : MonoBehaviour
{
    public Animator animator;
    public GameObject dialogueUI;
    public TMP_Text dialogueText;

    private void Start()
    {
        if (dialogueUI != null)
            dialogueUI.SetActive(false);

        if (animator != null)
            animator.SetBool("IsTalking", false);
    }

    public void Interact()
    {

        if (animator != null)
            animator.SetBool("IsTalking", true);


        if (dialogueUI != null && dialogueText != null)
        {
            dialogueUI.SetActive(true);
            dialogueText.text = "Hello there!";
        }


        Invoke(nameof(HideDialogue), 3f);
    }

    public void HideDialogue()
    {
        if (dialogueUI != null)
            dialogueUI.SetActive(false);

        if (animator != null)
            animator.SetBool("IsTalking", false);
    }
}