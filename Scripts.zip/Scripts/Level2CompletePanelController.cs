using UnityEngine;
using TMPro;

public class Level2CompletePanelController : MonoBehaviour
{
    public TMP_Text totalCoinsText;

    private void OnEnable()
    {
        if (totalCoinsText != null)
        {
            int coins = CoinManager.Instance.coins;
            totalCoinsText.text = "Total Coins: " + coins.ToString();
        }
    }
}
