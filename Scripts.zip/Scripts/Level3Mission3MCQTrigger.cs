using UnityEngine;

public class Level3Mission3MCQTrigger : MonoBehaviour
{
    [SerializeField] private Level3Mission3MCQManager mcqManager;
    [SerializeField] private Animator playerAnimator;

    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || hasBeenAsked) return;

        if (playerAnimator == null)
            playerAnimator = other.GetComponent<Animator>();

        hasBeenAsked = true;

        string question = "If the price of 2l of pretal is 800, what is the price of 1500ml?";
        string[] options = { "600", "650", "550", "460" };
        int correctAnswerIndex = 0;

        mcqManager.ShowQuestion(question, options, correctAnswerIndex, playerAnimator);
    }
}
