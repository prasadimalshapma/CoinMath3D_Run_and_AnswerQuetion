using UnityEngine;

public class NPCMovement : MonoBehaviour
{
    public Transform pointA;        
    public Transform pointB;        
    public Transform player;        
    public float moveSpeed = 2f;    
    public float stopDistance = 3f; 

    private Vector3 startPos;
    private Vector3 endPos;

    void Start()
    {
        startPos = pointA.position;
        endPos = pointB.position;
    }

    void Update()
    {
        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        if (distanceToPlayer > stopDistance)
        {
            float time = Mathf.PingPong(Time.time * moveSpeed, 1);
            transform.position = Vector3.Lerp(startPos, endPos, time);
        }
       
    }
}
