﻿

using UnityEngine;

public class WatermarkTrigger : MonoBehaviour
{
    [SerializeField] private WatermarkMCQManager mcqManager;
    [SerializeField] private Animator playerAnimator;

    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || hasBeenAsked) return;

        if (playerAnimator == null)
            playerAnimator = other.GetComponent<Animator>();

        hasBeenAsked = true;

        string question = "If you want to move forward safely from here, answer this question:";
        string[] options = { "53", "56", "30", "100" };
        int correctAnswerIndex = 3;

        mcqManager.ShowQuestion(question, options, correctAnswerIndex, playerAnimator);
    }
}
