using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MathQuizManager : MonoBehaviour
{
    public TMP_Text questionText;
    public Button[] answerButtons;
    public TMP_Text feedbackText;
    private int correctAnswer;

    void Start()
    {
        GenerateNewQuestion();
    }

    void GenerateNewQuestion()
    {
        int a = Random.Range(1, 10);
        int b = Random.Range(1, 10);
        correctAnswer = a + b;
        questionText.text = "What is " + a + " + " + b + "?";

        int correctIndex = Random.Range(0, answerButtons.Length);

        for (int i = 0; i < answerButtons.Length; i++)
        {
            int answer;
            if (i == correctIndex)
            {
                answer = correctAnswer;
            }
            else
            {
                answer = correctAnswer + Random.Range(-3, 4);
                while (answer == correctAnswer)
                    answer = correctAnswer + Random.Range(-3, 4);
            }

            answerButtons[i].GetComponentInChildren<Text>().text = answer.ToString();

            int selected = answer;
            answerButtons[i].onClick.RemoveAllListeners();
            answerButtons[i].onClick.AddListener(() => CheckAnswer(selected));
        }

        feedbackText.text = "";
    }

    void CheckAnswer(int selectedAnswer)
    {
        if (selectedAnswer == correctAnswer)
        {
            feedbackText.text = "Correct!";
        }
        else
        {
            feedbackText.text = "Wrong!";
        }

        Invoke("GenerateNewQuestion", 1.5f);
    }
}
