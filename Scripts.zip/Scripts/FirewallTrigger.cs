using UnityEngine;

public class FirewallTrigger : MonoBehaviour
{
    public GameObject fireWall;
    public Animator[] npcAnimators;
    public GameObject missionPanel;
    public Animator playerAnimator;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player entered the trigger zone. Disabling firewall, NPCs clap, showing mission panel, and playing player victory animation.");

            if (fireWall != null)
            {
                fireWall.SetActive(false);
            }
            else
            {
                Debug.LogWarning("Firewall GameObject not assigned.");
            }

            foreach (Animator animator in npcAnimators)
            {
                if (animator != null)
                {
                    animator.SetTrigger("Clap");
                }
            }

            if (missionPanel != null)
            {
                missionPanel.SetActive(true);
            }
            else
            {
                Debug.LogWarning("Mission Panel GameObject not assigned.");
            }

            if (playerAnimator != null)
            {
                playerAnimator.SetTrigger("Victory");
            }
            else
            {
                Debug.LogWarning("Player Animator not assigned.");
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            Debug.Log("Player exited the trigger zone. Hiding mission panel.");
            if (missionPanel != null)
            {
                missionPanel.SetActive(false);
            }
        }
    }
}
