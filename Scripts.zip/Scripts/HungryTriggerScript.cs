using UnityEngine;

public class HungryTriggerScript : MonoBehaviour
{
    
    public GameObject hungryPanel;

    
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            hungryPanel.SetActive(true); 
        }
    }

    
    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            hungryPanel.SetActive(false); 
        }
    }
}
