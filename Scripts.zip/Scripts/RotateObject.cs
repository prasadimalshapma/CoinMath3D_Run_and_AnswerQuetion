using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateObject : MonoBehaviour
{
    public Vector3 rotationspeed = new Vector3(0, 30, 0);

    void Update()
    {
        transform.Rotate(rotationspeed * Time.deltaTime);
    }
}
