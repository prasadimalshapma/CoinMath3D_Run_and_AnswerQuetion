using UnityEngine;

[RequireComponent(typeof(CharacterController))]
[RequireComponent(typeof(Animator))]
public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;
    public float jumpHeight = 2f;
    public float gravity = 9.81f;

    private Animator animator;
    private CharacterController characterController;
    private Vector3 moveDirection;
    private float verticalVelocity;

    void Start()
    {
        animator = GetComponent<Animator>();
        characterController = GetComponent<CharacterController>();
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        if (animator.GetBool("IsTalking"))
        {
            animator.SetBool("IsMoving", false);
            return;
        }

        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        Vector3 inputDirection = new Vector3(horizontalInput, 0, verticalInput);
        inputDirection = Vector3.ClampMagnitude(inputDirection, 1f);

       
        if (Camera.main != null)
        {
            float cameraYaw = Camera.main.transform.eulerAngles.y;  
            transform.rotation = Quaternion.Euler(0f, cameraYaw, 0f);  
        }

        Vector3 move = transform.TransformDirection(inputDirection) * speed;

        if (characterController.isGrounded)
        {
            if (verticalVelocity < 0)
                verticalVelocity = -2f;

            if (Input.GetKeyDown(KeyCode.Space))
            {
                verticalVelocity = Mathf.Sqrt(jumpHeight * 2f * gravity);
                animator.SetTrigger("Jump");
            }
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }

        moveDirection = new Vector3(move.x, verticalVelocity, move.z);
        characterController.Move(moveDirection * Time.deltaTime);

        animator.SetBool("IsMoving", inputDirection.magnitude > 0.1f);
        animator.SetFloat("Speed", inputDirection.magnitude);
    }
}
