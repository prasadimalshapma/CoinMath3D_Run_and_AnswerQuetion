using UnityEngine;

public class GameLostHandler : MonoBehaviour
{
    public GameObject gameLostPanel;          
    public PlayerSpawner playerSpawner;        
    public GameObject player;                 

    void Update()
    {
        if (gameLostPanel.activeSelf && Input.GetKeyDown(KeyCode.E))
        {
            RetryGame();
        }
    }

    public void RetryGame()
    {
        
        playerSpawner.ResetPlayer();

       
        CoinManager.Instance.ResetCoins();

        
        gameLostPanel.SetActive(false);
    }
}
