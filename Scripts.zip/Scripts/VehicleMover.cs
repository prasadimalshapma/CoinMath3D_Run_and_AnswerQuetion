﻿using UnityEngine;

public class VehicleMover : MonoBehaviour
{
    public Transform[] positions; 
    public float moveSpeed = 5f;
    private int currentIndex = 0;

    
    public Transform player;
    public Transform dropPoint; 

    private bool playerDropped = false;

    void Update()
    {
        if (currentIndex < positions.Length)
        {
            Transform target = positions[currentIndex];
            transform.position = Vector3.MoveTowards(transform.position, target.position, moveSpeed * Time.deltaTime);

            if (Vector3.Distance(transform.position, target.position) < 0.1f)
            {
                currentIndex++;

               
                if (currentIndex == positions.Length && !playerDropped)
                {
                    DropPlayer();
                }
            }
        }
    }

    void DropPlayer()
    {
        
        player.SetParent(null);

       
        player.position = dropPoint.position;
        player.rotation = dropPoint.rotation;

        
        SkinnedMeshRenderer mesh = player.GetComponentInChildren<SkinnedMeshRenderer>();
        if (mesh != null)
        {
            mesh.enabled = true;
        }

        
        

        playerDropped = true;

        Debug.Log("Player dropped at Position 8");
    }
}
