﻿using UnityEngine;

public class NPCMissionTrigger : MonoBehaviour
{
    public Animator npcAnimator;
    public Animator playerAnimator;
    public GameObject missionStartPanel;

    private bool missionStarted = false;

    private void OnTriggerEnter(Collider other)
    {
        if (missionStarted) return;

        if (other.CompareTag("Player"))
        {
            missionStarted = true;

            npcAnimator.SetTrigger("Sad");

            playerAnimator.SetTrigger("IsTalking");

            missionStartPanel.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            
            missionStartPanel.SetActive(false);

            
            missionStarted = false;

            
            npcAnimator.ResetTrigger("Sad");
            playerAnimator.ResetTrigger("IsTalking");
        }
    }
}
