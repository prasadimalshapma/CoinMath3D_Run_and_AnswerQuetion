using UnityEngine;

public class StartMenuManager : MonoBehaviour
{
    public GameObject startMenuPanel;   
    public GameObject playerController; 

    void Start()
    {
       
        startMenuPanel.SetActive(true);
        if (playerController != null)
            playerController.SetActive(false); 

        Time.timeScale = 0f; 
    }

    public void StartGame()
    {
       
        startMenuPanel.SetActive(false);
        if (playerController != null)
            playerController.SetActive(true); 

        Time.timeScale = 1f;
    }
}
