using UnityEngine;

public class PondTrigger : MonoBehaviour
{
    public GameObject pondPanel; 

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            pondPanel.SetActive(true); 
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            pondPanel.SetActive(false); 
        }
    }
}
