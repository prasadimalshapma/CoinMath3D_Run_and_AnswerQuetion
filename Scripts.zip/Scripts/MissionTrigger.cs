﻿using UnityEngine;

public class MissionTrigger : MonoBehaviour
{
    [SerializeField] private MCQManager9 mcqManager;
    [SerializeField] private Animator playerAnimator;

    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || hasBeenAsked) return;

        if (playerAnimator == null)
            playerAnimator = other.GetComponent<Animator>();

        hasBeenAsked = true;

        string question = "If you want to save your friends, Give me a correct Answer for this: 8+9/3*6";
        string[] options = { "26", "10", "34", "27" };
        int correctAnswerIndex = 0;

        mcqManager.ShowQuestion(question, options, correctAnswerIndex, playerAnimator);
    }
}
