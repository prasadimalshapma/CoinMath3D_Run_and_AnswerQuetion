using UnityEngine;

public class ArrowHideTrigger : MonoBehaviour
{
    public GameObject arrowIndicator;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            arrowIndicator.SetActive(false);
        }
    }
}
