﻿using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;

public class LorryMCQManager : MonoBehaviour
{
    public GameObject lorryPanel;
    public TextMeshProUGUI questionText;
    public Button[] optionButtons;
    public TextMeshProUGUI feedbackText;
    public Color correctColor = Color.green;
    public Color wrongColor = Color.red;

    public GameObject waterBubbleEffect;
    public GameObject level2Mission2FailedPanel; 

    private int correctAnswerIndex;
    private bool answered = false;
    private Animator playerAnimator;
    private bool isListening = false;

    void Update()
    {
        if (!isListening || answered) return;

        if (Input.GetKeyDown(KeyCode.Alpha1)) CheckAnswer(0);
        if (Input.GetKeyDown(KeyCode.Alpha2)) CheckAnswer(1);
        if (Input.GetKeyDown(KeyCode.Alpha3)) CheckAnswer(2);
        if (Input.GetKeyDown(KeyCode.Alpha4)) CheckAnswer(3);
    }

    public void ShowQuestion(string question, string[] options, int correctIndex, Animator playerAnim)
    {
        lorryPanel.SetActive(true);
        answered = false;
        isListening = true;
        correctAnswerIndex = correctIndex;
        playerAnimator = playerAnim;

        questionText.text = question;
        feedbackText.gameObject.SetActive(false);

        for (int i = 0; i < optionButtons.Length; i++)
        {
            int index = i;
            optionButtons[i].interactable = true;
            optionButtons[i].GetComponent<Image>().color = Color.white;
            optionButtons[i].GetComponentInChildren<TextMeshProUGUI>().text = options[i];
            optionButtons[i].onClick.RemoveAllListeners();
            optionButtons[i].onClick.AddListener(() => CheckAnswer(index));
        }
    }

    public void CheckAnswer(int selectedIndex)
    {
        if (answered) return;
        answered = true;
        isListening = false;

        foreach (Button btn in optionButtons)
            btn.interactable = false;

        if (selectedIndex == correctAnswerIndex)
        {
            optionButtons[selectedIndex].GetComponent<Image>().color = correctColor;
            feedbackText.text = "✅ Correct!";
            feedbackText.color = correctColor;

            CoinManager.Instance.AddCoin(1000);

            if (waterBubbleEffect != null)
                waterBubbleEffect.SetActive(true);
        }
        else
        {
            optionButtons[selectedIndex].GetComponent<Image>().color = wrongColor;
            optionButtons[correctAnswerIndex].GetComponent<Image>().color = correctColor;
            feedbackText.text = "❌ Wrong Answer!";
            feedbackText.color = wrongColor;

            if (playerAnimator != null)
                playerAnimator.SetTrigger("sad");

            if (waterBubbleEffect != null)
                waterBubbleEffect.SetActive(false);

           
            if (level2Mission2FailedPanel != null)
                level2Mission2FailedPanel.SetActive(true);
        }

        feedbackText.gameObject.SetActive(true);
        StartCoroutine(HidePanelAfterDelay(3f));
    }

    private IEnumerator HidePanelAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        lorryPanel.SetActive(false);
    }

    public void HideBubbleEffect()
    {
        if (waterBubbleEffect != null)
            waterBubbleEffect.SetActive(false);
    }
}
