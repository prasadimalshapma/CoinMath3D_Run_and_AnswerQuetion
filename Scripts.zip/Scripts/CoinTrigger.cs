using UnityEngine;

public class CoinTrigger : MonoBehaviour
{
    public int coinReward = 100;
    private bool hasTriggered = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!hasTriggered && other.CompareTag("Player"))
        {
            CoinManager.Instance.AddCoin(coinReward);
            hasTriggered = true;

            Debug.Log("Coins added: " + coinReward);
            Debug.Log("Trigger object to be destroyed: " + gameObject.name);

            Destroy(gameObject);


            gameObject.SetActive(false);
        }
    }
}
