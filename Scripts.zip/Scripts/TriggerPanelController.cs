using UnityEngine;

public class TriggerPanelController : MonoBehaviour
{
    public GameObject panel; 

    void Start()
    {
        if (panel != null)
        {
            panel.SetActive(false); 
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (panel != null)
            {
                panel.SetActive(true);
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (panel != null)
            {
                panel.SetActive(false); 
            }
        }
    }
}
