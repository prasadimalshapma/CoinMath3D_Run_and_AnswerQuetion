using UnityEngine;
using UnityEngine.UI;

public class MusicToggle : MonoBehaviour
{
    private AudioSource musicSource;
    private bool isMuted;

    [Header("Icon Settings")]
    public Image muteIcon;          
    public Sprite iconOn;           
    public Sprite iconOff;          

    void Start()
    {
        musicSource = GetComponent<AudioSource>();

        
        isMuted = PlayerPrefs.GetInt("MusicMuted", 0) == 1;
        musicSource.mute = isMuted;

        UpdateIcon();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            isMuted = !isMuted;
            musicSource.mute = isMuted;

            PlayerPrefs.SetInt("MusicMuted", isMuted ? 1 : 0);
            PlayerPrefs.Save();

            UpdateIcon();
        }
    }

    void UpdateIcon()
    {
        if (muteIcon != null)
        {
            muteIcon.sprite = isMuted ? iconOff : iconOn;
        }
    }
}