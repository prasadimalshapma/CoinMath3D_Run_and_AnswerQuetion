﻿using UnityEngine;

public class PlayerSpawner : MonoBehaviour
{
    public GameObject player;
    private Vector3 startPosition;
    private Quaternion startRotation;

    void Start()
    {

        startPosition = player.transform.position;
        startRotation = player.transform.rotation;
    }

    public void ResetPlayer()
    {

        player.transform.position = startPosition;
        player.transform.rotation = startRotation;


        Rigidbody rb = player.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
    }
}

