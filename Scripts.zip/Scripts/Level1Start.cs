using UnityEngine;
using TMPro;

public class Level1Start : MonoBehaviour
{
    public GameObject textObject; 

    void Start()
    {
        textObject.SetActive(false); 
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            textObject.SetActive(true); 
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            textObject.SetActive(false); 
        }
    }
}
