﻿using UnityEngine;
using UnityEngine.UI;

public class StartMenu : MonoBehaviour
{
    public GameObject panel; 
    public Button playButton; 

    private bool isPlayerInTrigger = false;

    void Start()
    {
        panel.SetActive(false); 
        playButton.onClick.AddListener(HidePanel); 
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            panel.SetActive(true); 
            isPlayerInTrigger = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInTrigger = false;
        }
    }

    void Update()
    {
        if (isPlayerInTrigger && panel.activeSelf && Input.GetKeyDown(KeyCode.E))
        {
            HidePanel(); 
        }
    }

    void HidePanel()
    {
        panel.SetActive(false);
    }
}
