using UnityEngine;

public class Level3Mission3Trigger : MonoBehaviour
{
    public GameObject missionPanel; 

    void Start()
    {
        missionPanel.SetActive(false); 
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            missionPanel.SetActive(true); 
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            missionPanel.SetActive(false); 
        }
    }
}
