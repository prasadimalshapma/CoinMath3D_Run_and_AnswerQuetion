using UnityEngine;

public class LorryMovement : MonoBehaviour
{
    public Transform[] waypointsSet1; 
    public Transform[] waypointsSet2; 
    public float speed = 8f;
    public Transform[] wheels;
    public float wheelRotationSpeed = 360f;

    private int currentIndex = 0;
    private bool isSecondPath = false;

    void Start()
    {
        if (waypointsSet1.Length > 1)
        {
            transform.LookAt(waypointsSet1[1].position);
        }
    }

    void Update()
    {
        Transform[] currentPath = isSecondPath ? waypointsSet2 : waypointsSet1;
        if (currentPath.Length == 0) return;

        Transform target = currentPath[currentIndex];
        transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);

        foreach (Transform wheel in wheels)
        {
            wheel.Rotate(Vector3.right, wheelRotationSpeed * Time.deltaTime);
        }

        if (Vector3.Distance(transform.position, target.position) < 0.1f)
        {
            currentIndex++;

            if (currentIndex < currentPath.Length)
            {
                transform.LookAt(currentPath[currentIndex].position);
            }
            else if (!isSecondPath)
            {
                isSecondPath = true;
                currentIndex = 0;
                if (waypointsSet2.Length > 0)
                {
                    transform.LookAt(waypointsSet2[0].position);
                }
            }
            else
            {
               
                isSecondPath = false;
                currentIndex = 0;
                if (waypointsSet1.Length > 0)
                {
                    transform.LookAt(waypointsSet1[0].position);
                }
            }
        }
    }
}
