using UnityEngine;

public class WaterDisappear : MonoBehaviour
{
    public GameObject waterObject;      
    public GameObject waterMarkPanel;   

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player")) 
        {
            if (waterObject != null)
                waterObject.SetActive(false);      

            if (waterMarkPanel != null)
                waterMarkPanel.SetActive(true);    
        }
    }
}
