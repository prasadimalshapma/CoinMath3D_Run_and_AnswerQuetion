using UnityEngine;

public class ShowQuizOnTrigger : MonoBehaviour
{
    public GameObject quizCanvas;  

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            quizCanvas.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            quizCanvas.SetActive(false);
        }
    }
}
