using UnityEngine;

public class VehicleController : MonoBehaviour
{
    public float moveSpeed = 10f;
    public float turnSpeed = 50f;

    private bool isDriving = false;

    public void SetDriving(bool driving)
    {
        isDriving = driving;
    }

    void Update()
    {
        if (!isDriving) return;

        float move = Input.GetAxis("Vertical") * moveSpeed * Time.deltaTime;
        float turn = Input.GetAxis("Horizontal") * turnSpeed * Time.deltaTime;

        transform.Translate(0, 0, move);
        transform.Rotate(0, turn, 0);
    }
}
