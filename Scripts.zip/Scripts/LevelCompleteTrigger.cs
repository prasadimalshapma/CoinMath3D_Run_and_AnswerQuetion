using UnityEngine;

public class LevelCompleteTrigger : MonoBehaviour
{
    public GameObject level2CompletePanel;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            level2CompletePanel.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            level2CompletePanel.SetActive(false); 
        }
    }
}
