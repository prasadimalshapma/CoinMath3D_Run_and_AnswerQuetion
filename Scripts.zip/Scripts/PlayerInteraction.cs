using UnityEngine;

public class PlayerInteraction : MonoBehaviour
{
    public float interactRange = 3f;
    public LayerMask interactableLayer;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;

            if (Physics.Raycast(ray, out hit, interactRange, interactableLayer))
            {
                NPCInteractable npc = hit.collider.GetComponent<NPCInteractable>();
                if (npc != null)
                {
                    npc.Interact();
                }
            }
        }
    }
}
