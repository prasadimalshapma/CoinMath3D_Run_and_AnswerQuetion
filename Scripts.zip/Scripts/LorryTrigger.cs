using UnityEngine;

public class LorryTrigger : MonoBehaviour
{
    [SerializeField] private LorryMCQManager mcqManager;
    [SerializeField] private Animator playerAnimator;

    private bool hasBeenAsked = false;

    private void OnTriggerEnter(Collider other)
    {
        if (!other.CompareTag("Player") || hasBeenAsked) return;

        if (playerAnimator == null)
            playerAnimator = other.GetComponent<Animator>();

        hasBeenAsked = true;

        string question = "Find total cost ?";
        string[] options = { "2900", "3300", "3100", "3500" };
        int correctAnswerIndex = 2;

        mcqManager.ShowQuestion(question, options, correctAnswerIndex, playerAnimator);
    }
}
