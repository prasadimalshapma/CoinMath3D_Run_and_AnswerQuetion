using UnityEngine;

public class PlayerResetManager : MonoBehaviour
{
    public GameObject player; 
    public GameObject gameLostPanel; 
    public Vector3 startPosition;

    private CharacterController controller;

    void Start()
    {
        controller = player.GetComponent<CharacterController>();
        startPosition = player.transform.position; 
    }

    void Update()
    {
        if (gameLostPanel.activeSelf && Input.GetKeyDown(KeyCode.E))
        {
            TryAgain();
        }
    }

    public void TryAgain()
    {
        
        controller.enabled = false;
        player.transform.position = startPosition;
        controller.enabled = true;

        
        CoinManager.Instance.ResetCoins();

       
        gameLostPanel.SetActive(false);

        
    }
}
