using UnityEngine;

[RequireComponent(typeof(Animator))]
public class IdleRunPreview : MonoBehaviour
{
    private Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
        animator.SetBool("IsMoving", true);  
        animator.SetFloat("Speed", 1f);      
    }

    void Update()
    {
        
    }
}
