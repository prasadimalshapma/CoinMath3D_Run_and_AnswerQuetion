using UnityEngine;

public class Level2Mission2Trigger : MonoBehaviour
{
    [SerializeField] private GameObject level2Mission2Panel;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && level2Mission2Panel != null)
        {
            level2Mission2Panel.SetActive(true);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player") && level2Mission2Panel != null)
        {
            level2Mission2Panel.SetActive(false);
        }
    }
}
