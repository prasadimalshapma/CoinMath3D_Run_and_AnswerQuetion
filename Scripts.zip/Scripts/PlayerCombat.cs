using UnityEngine;

public class PlayerCombat : MonoBehaviour
{
    private Animator animator;
    public float attackRange = 2f;
    public float attackDamage = 20f;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            animator.SetTrigger("Attack");
            TryAttackEnemy();
        }
    }

    void TryAttackEnemy()
    {
        RaycastHit hit;
       
        if (Physics.Raycast(transform.position, transform.forward, out hit, attackRange))
        {
            Debug.Log("Raycast hit: " + hit.collider.name);
            EnemyHealth enemy = hit.collider.GetComponent<EnemyHealth>();
            if (enemy != null)
            {
                enemy.TakeDamage(attackDamage);
            }
        }

       
        Debug.DrawRay(transform.position, transform.forward * attackRange, Color.red, 1f);
    }
}
